# Mi Huerto — proyecto Android y compilación APK

Proyecto Android que envuelve la app web local en un WebView. Los recursos están empaquetados en `app/src/main/assets/www`, por lo que el catálogo y el seguimiento básico funcionan sin conexión. Zona predeterminada: **Murcia capital · huerta del Segura**.

## Obtener un APK automáticamente en GitHub Actions

Este proyecto incluye `.github/workflows/build-apk.yml`, que compila un APK de prueba instalable y lo publica como artefacto de GitHub Actions.

1. Crea un repositorio en tu cuenta de GitHub (puede ser privado).
2. Sube el contenido de esta carpeta a la rama `main` (incluida la carpeta oculta `.github`).
3. En GitHub, abre la pestaña **Actions** y selecciona **Build Mi Huerto APK**.
4. Pulsa **Run workflow** si el flujo no se ha iniciado automáticamente al subir los archivos.
5. Cuando termine correctamente, abre esa ejecución y descarga el artefacto **mi-huerto-apk**. Es un ZIP que contiene `app-debug.apk`.
6. Descomprime el artefacto, sube `app-debug.apk` a Google Drive y descárgalo desde el móvil Android.

El APK debug se firma automáticamente con la clave de depuración de la compilación. Es adecuado para instalar y probar, pero no equivale a una versión de lanzamiento firmada con una clave privada propia. Para futuras actualizaciones que quieras distribuir como versión oficial, crea y guarda una clave de firma de lanzamiento.

## Compilar localmente

Requisitos: Java 17, Gradle 8.9 y Android SDK Platform 35 / Build Tools 35.0.0.

Desde esta carpeta ejecuta:

```bash
gradle --no-daemon assembleDebug
```

El resultado estará en `app/build/outputs/apk/debug/app-debug.apk`.

## Limitaciones

- Este ZIP contiene el código fuente y un flujo de compilación automática; no contiene un APK compilado.
- El calendario es orientativo y no consulta el tiempo meteorológico en tiempo real.
- Los datos del huerto se guardan localmente en el dispositivo. Exporta copias JSON para conservarlos.
